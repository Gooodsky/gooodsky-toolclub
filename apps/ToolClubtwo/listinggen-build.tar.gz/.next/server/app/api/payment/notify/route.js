var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payment/notify/route.js")
R.c("server/chunks/[root-of-the-server]__0q-7i9x._.js")
R.c("server/chunks/[root-of-the-server]__01o0~ee._.js")
R.c("server/chunks/listinggen__next-internal_server_app_api_payment_notify_route_actions_0_0zt.e.js")
R.m(18408)
module.exports=R.m(18408).exports
