var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/sync-user/route.js")
R.c("server/chunks/[root-of-the-server]__0-ja01g._.js")
R.c("server/chunks/[root-of-the-server]__01o0~ee._.js")
R.c("server/chunks/listinggen__next-internal_server_app_api_auth_sync-user_route_actions_05-sex~.js")
R.m(53788)
module.exports=R.m(53788).exports
