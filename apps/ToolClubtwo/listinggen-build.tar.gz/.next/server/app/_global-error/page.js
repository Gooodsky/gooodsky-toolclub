var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__0pw~d3_._.js")
R.c("server/chunks/ssr/07sm_next_dist_esm_build_templates_app-page_0i724.u.js")
R.c("server/chunks/ssr/[root-of-the-server]__09dnyv-._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0fl82x_._.js")
R.c("server/chunks/ssr/07sm_next_dist_client_components_builtin_global-error_12eiece.js")
R.c("server/chunks/ssr/listinggen__next-internal_server_app__global-error_page_actions_10q5rnm.js")
R.m(21163)
module.exports=R.m(21163).exports
