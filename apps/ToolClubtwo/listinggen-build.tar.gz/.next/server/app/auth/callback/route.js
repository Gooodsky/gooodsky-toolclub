var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__0aadh_u._.js")
R.c("server/chunks/07sm_0~-kgae._.js")
R.c("server/chunks/[root-of-the-server]__01o0~ee._.js")
R.c("server/chunks/listinggen__next-internal_server_app_auth_callback_route_actions_03ttjim.js")
R.m(53536)
module.exports=R.m(53536).exports
