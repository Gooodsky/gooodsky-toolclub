1:"$Sreact.fragment"
2:I[19537,["/_next/static/chunks/0tek3k1.chtrn.js","/_next/static/chunks/11-y0or0j4fqm.js"],"default"]
3:I[76005,["/_next/static/chunks/0tek3k1.chtrn.js","/_next/static/chunks/11-y0or0j4fqm.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"xAb3iVrGM0cSx-aaTjI0q"}
