globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/xAb3iVrGM0cSx-aaTjI0q/_buildManifest.js",
    "static/xAb3iVrGM0cSx-aaTjI0q/_ssgManifest.js",
    "static/xAb3iVrGM0cSx-aaTjI0q/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0jrte8f5g-ore.js",
    "static/chunks/0m3jm8_qhnnxl.js",
    "static/chunks/0k2~5vj-8rnty.js",
    "static/chunks/0g7c5r.cyykjh.js",
    "static/chunks/0_b~jzag93vc7.js",
    "static/chunks/turbopack-0l1lxkkq7x.zs.js"
  ]
};
