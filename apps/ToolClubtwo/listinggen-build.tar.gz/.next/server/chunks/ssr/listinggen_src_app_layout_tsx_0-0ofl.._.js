module.exports=[73598,a=>{"use strict";var b=a.i(64096);a.s(["default",0,function({children:a}){return(0,b.jsx)("html",{lang:"zh-CN",children:(0,b.jsx)("body",{children:a})})},"metadata",0,{title:"ToolClub - 跨境商品详情生成助手",description:"一条中文商品信息，秒级生成多语言、多平台商品详情页，覆盖 Amazon、Shopee、Lazada、TikTok Shop"}])},11985,a=>{a.n(a.i(73598))}];

//# sourceMappingURL=listinggen_src_app_layout_tsx_0-0ofl.._.js.map