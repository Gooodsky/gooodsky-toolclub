module.exports=[69963,(a,b,c)=>{}];

//# sourceMappingURL=0xqt__next-internal_server_app_dashboard_projects_%5Bid%5D_page_actions_0a_49lx.js.map