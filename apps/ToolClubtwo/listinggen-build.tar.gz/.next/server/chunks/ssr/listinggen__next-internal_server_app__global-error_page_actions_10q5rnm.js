module.exports=[87462,(a,b,c)=>{}];

//# sourceMappingURL=listinggen__next-internal_server_app__global-error_page_actions_10q5rnm.js.map