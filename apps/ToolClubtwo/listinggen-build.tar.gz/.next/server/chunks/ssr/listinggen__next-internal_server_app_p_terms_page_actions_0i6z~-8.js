module.exports=[78909,(a,b,c)=>{}];

//# sourceMappingURL=listinggen__next-internal_server_app_p_terms_page_actions_0i6z~-8.js.map